
// You can write more code here

/* START OF COMPILED CODE */

class Level extends Phaser.Scene {

	constructor() {
		super("Level");

		/* START-USER-CTR-CODE */
		// Write your code here.
		/* END-USER-CTR-CODE */
	}

	/** @returns {void} */
	editorCreate() {

		// player1
		const player1 = this.add.text(520, 218, "", {});
		player1.setOrigin(0.5, 0.5);
		player1.text = "%Player1Name%";
		player1.setStyle({ "fontFamily": "Arial", "fontSize": "24px" });

		// onAwakeScript_1
		const onAwakeScript_1 = new OnAwakeScript(player1);

		// fadeActionScript
		const fadeActionScript = new FadeActionScript(onAwakeScript_1);

		// tile6
		const tile6 = this.add.image(663, 341, "empty");

		// tile2
		const tile2 = this.add.image(663, 291, "empty");

		// tile1
		const tile1 = this.add.image(614, 291, "empty");

		// tile5
		const tile5 = this.add.image(614, 340, "empty");

		// tile7
		const tile7 = this.add.image(712, 339, "empty");

		// tile3
		const tile3 = this.add.image(712, 289, "empty");

		// tile8
		const tile8 = this.add.image(761, 340, "empty");

		// tile4
		const tile4 = this.add.image(761, 289, "empty");

		// player2
		const player2 = this.add.text(883, 208, "", {});
		player2.setOrigin(0.5, 0.5);
		player2.text = "%Player2Name%";
		player2.setStyle({ "fontFamily": "Arial", "fontSize": "24px" });

		// onAwakeScript
		const onAwakeScript = new OnAwakeScript(player2);

		// fadeActionScript_1
		const fadeActionScript_1 = new FadeActionScript(onAwakeScript);

		// container_1
		const container_1 = this.add.container(890, 282);

		// text_1
		const text_1 = this.add.text(0, 26, "", {});
		text_1.text = "Attack";
		container_1.add(text_1);

		// text
		const text = this.add.text(0, 0, "", {});
		text.text = "Move";
		container_1.add(text);

		// fadeActionScript (prefab fields)
		fadeActionScript.fadeDirection = "FadeIn";

		// fadeActionScript (components)
		const fadeActionScriptDurationConfigComp = new DurationConfigComp(fadeActionScript);
		fadeActionScriptDurationConfigComp.duration = 1500;

		// fadeActionScript_1 (prefab fields)
		fadeActionScript_1.fadeDirection = "FadeIn";

		// fadeActionScript_1 (components)
		const fadeActionScript_1DurationConfigComp = new DurationConfigComp(fadeActionScript_1);
		fadeActionScript_1DurationConfigComp.duration = 1500;

		this.player1 = player1;
		this.tile6 = tile6;
		this.tile2 = tile2;
		this.tile1 = tile1;
		this.tile5 = tile5;
		this.tile7 = tile7;
		this.tile3 = tile3;
		this.tile8 = tile8;
		this.tile4 = tile4;
		this.player2 = player2;

		this.events.emit("scene-awake");
	}

	/** @type {Phaser.GameObjects.Text} */
	player1;
	/** @type {Phaser.GameObjects.Image} */
	tile6;
	/** @type {Phaser.GameObjects.Image} */
	tile2;
	/** @type {Phaser.GameObjects.Image} */
	tile1;
	/** @type {Phaser.GameObjects.Image} */
	tile5;
	/** @type {Phaser.GameObjects.Image} */
	tile7;
	/** @type {Phaser.GameObjects.Image} */
	tile3;
	/** @type {Phaser.GameObjects.Image} */
	tile8;
	/** @type {Phaser.GameObjects.Image} */
	tile4;
	/** @type {Phaser.GameObjects.Text} */
	player2;

	/* START-USER-CODE */

	// array to store the tiles
	tiles = [];

	char1_posX = 1;
	char1_posY = 1;

	char2_posX = 7;
	char2_posY = 2;

	// Write more your code here

	create() {
		// This generates a map with 7x9 tiles.
		this.generateMap(7,9);
		
		this.editorCreate();

		// Sync the game state every 2 seconds
		var TIME_BETWEEN_SYNC = 2000;

		// call function every 2 seconds (TIME_BETWEEN_SYNC milliseconds)
		setInterval(() => {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = () => {
				if (xhttp.readyState == 4) {
					// Parse the JSON response
					var data = JSON.parse(xhttp.responseText);
					console.log(data);

					// Get the player names from the response
					var player1Name = data[0].Player1
					var player2Name = data[0].Player2

					// Set the player names in the game
					this.player1.text = player1Name;
					this.player2.text = player2Name;

					// !!! If the tiles were added manually in the editor, you can use the following code:
					this.tile1.setTexture("character_rambow_blue");
					this.tile8.setTexture("character_decibelle_red");

					// !!! If the tiles were added dynamically, you can use the following code:
					// Cleans the previous position of the characters
					this.tiles[(this.char1_posX-1)  + (this.char1_posY-1) * 7].setTexture("empty");
					this.tiles[(this.char2_posX-1)  + (this.char2_posY-1) * 7].setTexture("empty");

					// Move the characters
					this.char1_posX++;
					if (this.char1_posX > 7)
						this.char1_posX = 1;
					this.char2_posX--;
					if (this.char2_posX < 1)
						this.char2_posX = 7;

					// Set the new position of the characters
					this.tiles[(this.char1_posX-1)  + (this.char1_posY-1) * 7].setTexture("character_rambow_blue");
					this.tiles[(this.char2_posX-1)  + (this.char2_posY-1) * 7].setTexture("character_decibelle_red");
				}
			};

			// Send a GET request to the server (just testing with /match/11 endpoint)
			xhttp.open("GET", "/match/11", true);
			xhttp.send();
		}, TIME_BETWEEN_SYNC)
	}

	// 💩 Disclaimer: If you found this hard to understand/handle, add the tiles manually in the editor and use them!
	// Function that receives x and y amount of tiles and generates a map.
	generateMap(xAmount, yAmount){
		// 7 (horizontal) x 9 (vertical) tiles
		for (var x = 0; x < xAmount; x++){
			for (var y = 0; y < yAmount; y++){
				const tile = this.add.image(100 + x * 50, 100 + y * 50, "empty");

				// We store the tile in an array for later use.
				this.tiles[x + y * xAmount] = tile;
			}
		}
	}
	/* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
